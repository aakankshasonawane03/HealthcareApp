
package config

import (
	"context"
	"os"
	"path/filepath"
	"runtime"

	firebase "firebase.google.com/go/v4"
	"firebase.google.com/go/v4/messaging"
	"google.golang.org/api/option"
)

func InitFirebase() (*messaging.Client, error) {
	ctx := context.Background()

	_, currentFile, _, ok := runtime.Caller(0)
	if !ok {
		return nil, os.ErrNotExist
	}

	projectRoot := filepath.Clean(
		filepath.Join(filepath.Dir(currentFile), "../.."),
	)

	credentialsFile := filepath.Join(
		projectRoot,
		"firebase-service-account.json",
	)

	if _, err := os.Stat(credentialsFile); err != nil {
		return nil, err
	}

	opt := option.WithCredentialsFile(credentialsFile)

	app, err := firebase.NewApp(ctx, nil, opt)
	if err != nil {
		return nil, err
	}

	client, err := app.Messaging(ctx)
	if err != nil {
		return nil, err
	}

	return client, nil
}